import { Component } from '@angular/core';

@Component({
  selector: 'app-demo-example',
  templateUrl: './demo-example.component.html',
  styleUrls: ['./demo-example.component.css']
})
export class DemoExampleComponent {

}
