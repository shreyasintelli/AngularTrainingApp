import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ProductListComponent} from './product-list/product-list.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { SortExampleComponent } from './sort-example/sort-example.component';
import { SearchPipe } from './search.pipe';
import { DisplayArrayPipe } from './display-array.pipe';
import { ProductSearchComponent } from './product-search/product-search.component';
import { SortArrPipe } from './sort-arr.pipe';
import { DemoExampleComponent } from './demo-example/demo-example.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditproddComponent } from './editprodd/editprodd.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ProductListComponent,
    AddToCartComponent,
    ParentComponent,
    ChildComponent,
    HomeComponent,
    CartComponent,
    SortExampleComponent,
    SearchPipe,
    DisplayArrayPipe,
    ProductSearchComponent,
    SortArrPipe,
    DemoExampleComponent,
    RegisterFormComponent,
    ProductManageComponent,
    EditProductComponent,
    EditproddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
